// Node.js版本检查脚本
// 模拟localStorage检查指定用户是否存在
const fs = require('fs');
const path = require('path');

console.log('正在检查用户是否存在...');

try {
  // 在Node.js环境中，我们可以模拟检查localStorage的内容
  // 由于localStorage是浏览器特性，我们这里直接检查应用是否应该在localStorage中存储了这个用户
  
  // 输出提示信息
  console.log('注意：在Node.js环境中无法直接访问浏览器的localStorage');
  console.log('要检查浏览器中是否存在该用户，请在浏览器控制台执行以下代码：');
  console.log('');
  console.log('// 复制以下代码到浏览器控制台');
  console.log('const users = JSON.parse(localStorage.getItem(\'users\') || \'{}\');');
  console.log('console.log(\'所有用户名: \', Object.keys(users));');
  console.log('const targetUser = users[\'123456\'];');
  console.log('console.log(\'是否存在学号为123456的用户: \', !!targetUser);');
  console.log('if (targetUser) {');
  console.log('  console.log(\'用户详情: \', targetUser);');
  console.log('}');
  console.log('');
  console.log('// 或者查找学生名为hhh的用户');
  console.log('for (const username in users) {');
  console.log('  const user = users[username];');
  console.log('  if (user.name === \'hhh\' || user.studentName === \'hhh\') {');
  console.log('    console.log(\'找到学生名为hhh的用户！\', user);');
  console.log('    break;');
  console.log('  }');
  console.log('}');
  
  console.log('\n提示：如果您使用的是模拟登录，用户数据存储在浏览器的localStorage中，而不是服务器数据库中。');
  console.log('请在浏览器中打开应用，按F12打开开发者工具，切换到Console选项卡，粘贴上述代码并按回车执行。');
  
} catch (error) {
  console.error('检查用户时发生错误:', error);
}