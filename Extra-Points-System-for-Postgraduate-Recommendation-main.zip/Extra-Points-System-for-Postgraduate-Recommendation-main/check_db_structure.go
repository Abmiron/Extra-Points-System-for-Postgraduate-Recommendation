package main

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/lib/pq"
)

func main() {
	// 数据库连接信息
	dbURL := "host=localhost port=5432 user=postgres password=123456 dbname=hd_golang sslmode=disable"

	// 连接数据库
	db, err := sql.Open("postgres", dbURL)
	if err != nil {
		log.Fatalf("无法连接到数据库: %v\n", err)
	}
	defer db.Close()

	// 测试连接
	err = db.Ping()
	if err != nil {
		log.Fatalf("数据库连接测试失败: %v\n", err)
	}

	fmt.Println("数据库连接成功")

	// 查询students表结构的简化版本
	fmt.Println("\n1. 查询students表结构:")
	rows, err := db.Query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'students' ORDER BY ordinal_position")
	if err != nil {
		log.Fatalf("查询students表结构失败: %v\n", err)
	}
	defer rows.Close()

	fmt.Println("字段名 | 数据类型")
	fmt.Println("------|---------")
	for rows.Next() {
		var columnName, dataType string
		if err := rows.Scan(&columnName, &dataType); err != nil {
			log.Fatalf("扫描结果失败: %v\n", err)
		}
		fmt.Printf("%s | %s\n", columnName, dataType)
	}

	// 查询students表中的最新数据，特别关注test_student_log_test用户
	fmt.Println("\n2. 查询students表中的最新数据:")
	rows, err = db.Query("SELECT id, student_id, user_id, name, department, major FROM students ORDER BY id DESC LIMIT 5")
	if err != nil {
		log.Fatalf("查询students表失败: %v\n", err)
	}
	defer rows.Close()

	fmt.Println("ID\tStudentID\tUserID\tName\tDepartment\tMajor")
	fmt.Println("-----------------------------------------------------------------")
	for rows.Next() {
		var id int
		var studentID string
		var userID sql.NullInt64 // 使用NullInt64处理可能为NULL的值
		var name, department, major string
		
		if err := rows.Scan(&id, &studentID, &userID, &name, &department, &major); err != nil {
			log.Fatalf("扫描结果失败: %v\n", err)
		}
		
		userIDStr := "NULL"
		if userID.Valid {
			userIDStr = fmt.Sprintf("%d", userID.Int64)
		}
		
		fmt.Printf("%d\t%s\t\t%s\t%s\t%s\t\t%s\n", id, studentID, userIDStr, name, department, major)
	}

	// 特别检查test_student_log_test用户的数据
	fmt.Println("\n3. 检查test_student_log_test用户的数据:")
	var userID int
	var username, studentID string
	var name, department, major string
	
	// 先查询users表获取用户ID
	err = db.QueryRow("SELECT id, username FROM users WHERE username = 'test_student_log_test'").Scan(&userID, &username)
	if err != nil {
		fmt.Printf("未找到用户test_student_log_test: %v\n", err)
	} else {
		fmt.Printf("用户信息: ID=%d, Username=%s\n", userID, username)
		// 查询对应的students表记录
		err = db.QueryRow("SELECT student_id, name, department, major FROM students WHERE user_id = $1", userID).Scan(&studentID, &name, &department, &major)
		if err != nil {
			fmt.Printf("未找到对应的学生记录: %v\n", err)
		} else {
			fmt.Printf("学生信息: StudentID=%s, Name=%s, Department=%s, Major=%s\n", studentID, name, department, major)
		}
	}

	fmt.Println("\n数据库检查完成")
}
