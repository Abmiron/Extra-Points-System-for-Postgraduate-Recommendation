-- 检查users表中的测试学生
SELECT id, username, role, status FROM users WHERE username = 'test_student_log_test';

-- 检查students表中对应的学生记录 (使用正确的user_id关联)
SELECT id, student_id, user_id, name, department, major FROM students WHERE user_id IN (SELECT id FROM users WHERE username = 'test_student_log_test');

-- 查看students表的结构
SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'students';

-- 查看students表中的最新数据
SELECT id, student_id, user_id, name, department, major FROM students ORDER BY id DESC LIMIT 5;