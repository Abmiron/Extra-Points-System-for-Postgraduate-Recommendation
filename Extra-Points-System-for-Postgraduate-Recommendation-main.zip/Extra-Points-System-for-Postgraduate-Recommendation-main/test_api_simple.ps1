# Simple API test script
try {
    Write-Host "Testing backend connection..."
    $response = Invoke-WebRequest -Uri "http://localhost:9001" -Method Get -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
    Write-Host "Backend service is running! Status code: $($response.StatusCode)"
    exit 0
} catch {
    Write-Host "Backend connection failed!"
    Write-Host "Error: $($_.Exception.Message)"
    exit 1
}