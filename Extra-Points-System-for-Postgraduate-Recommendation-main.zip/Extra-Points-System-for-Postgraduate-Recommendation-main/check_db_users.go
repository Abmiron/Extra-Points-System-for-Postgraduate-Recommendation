package main

import (
	"database/sql"
	"fmt"
	_ "github.com/lib/pq"
)

func main() {
	// 数据库连接参数
	db, err := sql.Open("postgres", "host=localhost port=5432 user=postgres password=123456 dbname=hd_golang sslmode=disable")
	if err != nil {
		fmt.Printf("数据库连接失败: %v\n", err)
		return
	}
	defer db.Close()

	// 检查连接
	if err := db.Ping(); err != nil {
		fmt.Printf("数据库连接失败: %v\n", err)
		return
	}
	fmt.Println("数据库连接成功")

	// 检查users表中的学生记录
	fmt.Println("\n----- Users表中的学生记录 -----")
	rows, err := db.Query("SELECT id, username, role, status FROM users WHERE username = 'test_student_new'")
	if err != nil {
		fmt.Printf("查询users表失败: %v\n", err)
		return
	}
	defer rows.Close()

	var found bool
	for rows.Next() {
		found = true
		var id int
		var username, role, status string
		if err := rows.Scan(&id, &username, &role, &status); err != nil {
			fmt.Printf("扫描users表记录失败: %v\n", err)
			continue
		}
		fmt.Printf("ID: %d, Username: %s, Role: %s, Status: %s\n", id, username, role, status)
	}

	if !found {
		fmt.Println("在users表中未找到学生记录")
	}

	// 检查students表中的记录
	fmt.Println("\n----- Students表中的记录 -----")
	rows2, err := db.Query("SELECT student_id, name, department, major FROM students WHERE student_id IN (SELECT id FROM users WHERE username = 'test_student_new')")
	if err != nil {
		fmt.Printf("查询students表失败: %v\n", err)
		return
	}
	defer rows2.Close()

	var foundStudent bool
	for rows2.Next() {
		foundStudent = true
		var studentID int
		var name, department, major string
		if err := rows2.Scan(&studentID, &name, &department, &major); err != nil {
			fmt.Printf("扫描students表记录失败: %v\n", err)
			continue
		}
		fmt.Printf("StudentID: %d, Name: %s, Department: %s, Major: %s\n", studentID, name, department, major)
	}

	if !foundStudent {
		fmt.Println("在students表中未找到学生记录")
	}

	// 检查数据库表结构，看看students表的实际字段名
	fmt.Println("\n----- Students表结构 -----")
	rows3, err := db.Query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'students'")
	if err != nil {
		fmt.Printf("查询表结构失败: %v\n", err)
		return
	}
	defer rows3.Close()

	for rows3.Next() {
		var columnName, dataType string
		if err := rows3.Scan(&columnName, &dataType); err != nil {
			fmt.Printf("扫描表结构失败: %v\n", err)
			continue
		}
		fmt.Printf("列名: %s, 数据类型: %s\n", columnName, dataType)
	}
}
