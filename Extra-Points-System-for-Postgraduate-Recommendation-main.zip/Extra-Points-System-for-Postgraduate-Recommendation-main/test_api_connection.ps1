# 测试后端API连接的PowerShell脚本
Write-Host "测试后端服务连接..."

# 使用更简单的方式测试API连接
try {
    # 测试GET请求，检查服务是否运行
    $response = Invoke-WebRequest -Uri "http://localhost:9001" -Method Get -UseBasicParsing -ErrorAction Stop
    Write-Host "后端服务基础连接成功!"
    Write-Host "状态码: $($response.StatusCode)"
    
    # 尝试测试POST请求
    try {
        $body = @{
            username = "admin"
            password = "123456"
        } | ConvertTo-Json
        
        $loginResponse = Invoke-WebRequest -Uri "http://localhost:9001/api/auth/login" -Method Post -ContentType "application/json" -Body $body -UseBasicParsing -ErrorAction Stop
        Write-Host "\n登录API测试成功!"
        Write-Host "状态码: $($loginResponse.StatusCode)"
        
        if ($loginResponse.Content) {
            Write-Host "响应内容: $($loginResponse.Content)"
        }
        
        exit 0
    } catch {
        Write-Host "\n登录API测试失败，但基础连接正常"
        Write-Host "错误: $($_.Exception.Message)"
        Write-Host "提示: 服务运行但可能需要正确的登录凭据或API路径"
        exit 0
    }
} catch {
    Write-Host "测试失败: 无法连接到后端服务"
    Write-Host "错误信息: $($_.Exception.Message)"
    Write-Host "请检查后端服务是否正确运行在9001端口"
    exit 1
}