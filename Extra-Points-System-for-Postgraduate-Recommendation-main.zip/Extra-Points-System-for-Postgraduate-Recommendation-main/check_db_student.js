// Node.js脚本：检查PostgreSQL数据库中的学生数据
const { Client } = require('pg');

// 数据库连接配置
const config = {
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'postgres',
  port: 5432,
};

// 创建客户端实例
const client = new Client(config);

async function checkStudentData() {
  try {
    // 连接数据库
    console.log('正在连接数据库...');
    await client.connect();
    console.log('数据库连接成功！');

    // 1. 查看students表结构
    console.log('\n1. 查看students表结构：');
    const tableStructure = await client.query(
      'SELECT column_name, data_type FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position',
      ['students']
    );
    console.log('字段名\t\t数据类型');
    console.log('-------------------------');
    tableStructure.rows.forEach(row => {
      console.log(`${row.column_name.padEnd(16)}\t${row.data_type}`);
    });

    // 2. 检查test_student_log_test用户
    console.log('\n2. 检查test_student_log_test用户：');
    const userQuery = await client.query(
      'SELECT id, username, role, status FROM users WHERE username = $1',
      ['test_student_log_test']
    );
    
    if (userQuery.rows.length === 0) {
      console.log('未找到用户test_student_log_test');
    } else {
      const user = userQuery.rows[0];
      console.log(`用户信息: ID=${user.id}, Username=${user.username}, Role=${user.role}, Status=${user.status}`);
      
      // 3. 检查对应的students表记录
      console.log('\n3. 检查对应的students表记录：');
      const studentQuery = await client.query(
        'SELECT id, student_id, user_id, name, department, major FROM students WHERE user_id = $1',
        [user.id]
      );
      
      if (studentQuery.rows.length === 0) {
        console.log('未找到对应的学生记录');
      } else {
        const student = studentQuery.rows[0];
        console.log(`学生信息:`);
        console.log(`  ID: ${student.id}`);
        console.log(`  StudentID: ${student.student_id}`);
        console.log(`  UserID: ${student.user_id}`);
        console.log(`  Name: ${student.name}`);
        console.log(`  Department: ${student.department}`);
        console.log(`  Major: ${student.major}`);
      }
    }

    // 4. 查看students表中的最新数据
    console.log('\n4. 查看students表中的最新数据：');
    const latestStudents = await client.query(
      'SELECT id, student_id, user_id, name, department, major FROM students ORDER BY id DESC LIMIT 5'
    );
    
    if (latestStudents.rows.length === 0) {
      console.log('students表中没有数据');
    } else {
      console.log('ID\tStudentID\tUserID\tName\tDepartment\tMajor');
      console.log('-----------------------------------------------------------------------------------');
      latestStudents.rows.forEach(student => {
        console.log(`${student.id}\t${student.student_id}\t\t${student.user_id}\t${student.name}\t${student.department}\t\t${student.major}`);
      });
    }

    // 5. 特别检查是否有student_id字段为空的记录
    console.log('\n5. 检查是否有student_id为空的记录：');
    const nullStudentIdQuery = await client.query(
      'SELECT id, student_id, user_id, name FROM students WHERE student_id IS NULL OR student_id = \'\' LIMIT 5'
    );
    
    if (nullStudentIdQuery.rows.length === 0) {
      console.log('没有发现student_id为空的记录');
    } else {
      console.log(`发现 ${nullStudentIdQuery.rows.length} 条student_id为空的记录：`);
      nullStudentIdQuery.rows.forEach(student => {
        console.log(`  ID: ${student.id}, UserID: ${student.user_id}, Name: ${student.name}, StudentID: ${student.student_id || 'NULL'}`);
      });
    }

  } catch (err) {
    console.error('数据库操作错误:', err);
  } finally {
    // 关闭连接
    await client.end();
    console.log('\n数据库连接已关闭');
  }
}

// 执行检查
checkStudentData();
