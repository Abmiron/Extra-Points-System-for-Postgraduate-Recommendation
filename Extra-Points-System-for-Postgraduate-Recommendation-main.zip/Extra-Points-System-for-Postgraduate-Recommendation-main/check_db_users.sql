-- 查询所有用户账号信息
SELECT u.id, u.username, u.role, u.status, u.created_at, u.last_login_at,
       COALESCE(s.student_id, '') as student_id,
       COALESCE(s.name, '') as student_name,
       COALESCE(s.department, '') as department,
       COALESCE(s.major, '') as major
FROM users u
LEFT JOIN students s ON u.id = s.user_id
ORDER BY u.created_at DESC;

-- 查询用户数量统计
SELECT role, status, COUNT(*) as count
FROM users
GROUP BY role, status;
