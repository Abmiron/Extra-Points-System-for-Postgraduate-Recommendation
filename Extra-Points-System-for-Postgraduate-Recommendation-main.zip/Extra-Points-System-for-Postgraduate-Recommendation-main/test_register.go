package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

// RegisterRequest 注册请求结构
type RegisterRequest struct {
	Username string `json:"username"`
	Name     string `json:"name"`
	Password string `json:"password"`
	Role     string `json:"role"`
}

// RegisterResponse 注册响应结构
type RegisterResponse struct {
	Message string `json:"message"`
}

func main() {
	// 创建一个学生注册请求
	reqBody := RegisterRequest{
		Username: "test_student_log_test",
		Name:     "日志测试学生",
		Password: "password123",
		Role:     "student",
	}

	// 转换为JSON
	jsonData, err := json.Marshal(reqBody)
	if err != nil {
		fmt.Println("JSON marshaling failed:", err)
		return
	}

	// 发送POST请求到注册接口
	resp, err := http.Post(
		"http://localhost:8088/api/auth/register",
		"application/json",
		bytes.NewBuffer(jsonData),
	)
	if err != nil {
		fmt.Println("HTTP request failed:", err)
		return
	}
	defer resp.Body.Close()

	// 读取响应
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Reading response failed:", err)
		return
	}

	// 打印响应状态码和内容
	fmt.Printf("Response Status: %d\n", resp.StatusCode)
	fmt.Printf("Response Body: %s\n", string(body))

	// 如果响应成功，解析响应
	if resp.StatusCode == http.StatusCreated {
		var response RegisterResponse
		if err := json.Unmarshal(body, &response); err != nil {
			fmt.Println("JSON unmarshaling failed:", err)
			return
		}
		fmt.Printf("Registration successful: %s\n", response.Message)
	} else {
		fmt.Println("Registration failed")
	}
}
