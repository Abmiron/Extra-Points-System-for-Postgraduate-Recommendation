package main

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/lib/pq"
)

func main() {
	// 数据库连接信息
	db, err := sql.Open("postgres", "host=localhost port=5432 user=postgres password=postgres dbname=postgres sslmode=disable")
	if err != nil {
		log.Fatalf("无法连接到数据库: %v", err)
	}
	defer db.Close()

	// 测试连接
	err = db.Ping()
	if err != nil {
		log.Fatalf("数据库连接测试失败: %v", err)
	}

	fmt.Println("数据库连接成功")

	// 1. 检查students表结构，确认student_id字段存在
	fmt.Println("\n1. 检查students表结构:")
	rows, err := db.Query("SELECT column_name FROM information_schema.columns WHERE table_name = 'students' ORDER BY ordinal_position")
	if err != nil {
		log.Fatalf("查询表结构失败: %v", err)
	}
	defer rows.Close()

	fmt.Println("表字段:")
	columns := []string{}
	studentIdExists := false
	for rows.Next() {
		var columnName string
		if err := rows.Scan(&columnName); err != nil {
			log.Fatalf("扫描结果失败: %v", err)
		}
		columns = append(columns, columnName)
		if columnName == "student_id" {
			studentIdExists = true
		}
	}

	fmt.Println(columns)
	if studentIdExists {
		fmt.Println("✓ student_id字段已存在")
	} else {
		fmt.Println("✗ student_id字段不存在")
	}

	// 2. 检查test_student_log_test用户是否存在
	fmt.Println("\n2. 检查test_student_log_test用户:")
	var userId int
	var username, role, status string
	err = db.QueryRow("SELECT id, username, role, status FROM users WHERE username = 'test_student_log_test'").Scan(&userId, &username, &role, &status)
	if err != nil {
		fmt.Printf("未找到用户: %v\n", err)
	} else {
		fmt.Printf("用户信息: ID=%d, Username=%s, Role=%s, Status=%s\n", userId, username, role, status)

		// 3. 检查对应的学生记录
		fmt.Println("\n3. 检查对应的学生记录:")
		var studentId, name, department, major string
		var studentUserId int
		err = db.QueryRow("SELECT student_id, user_id, name, department, major FROM students WHERE user_id = $1", userId).Scan(&studentId, &studentUserId, &name, &department, &major)
		if err != nil {
			fmt.Printf("未找到对应的学生记录: %v\n", err)
		} else {
			fmt.Printf("学生记录存在！\n")
			fmt.Printf("  StudentID: %s\n", studentId)
			fmt.Printf("  UserID: %d\n", studentUserId)
			fmt.Printf("  Name: %s\n", name)
			fmt.Printf("  Department: %s\n", department)
			fmt.Printf("  Major: %s\n", major)

			if studentId != "" {
				fmt.Println("✓ StudentID已正确存储")
			} else {
				fmt.Println("✗ StudentID为空")
			}
		}
	}

	// 4. 查看最新的学生记录
	fmt.Println("\n4. 查看最新的5条学生记录:")
	rows, err = db.Query("SELECT id, student_id, user_id, name FROM students ORDER BY id DESC LIMIT 5")
	if err != nil {
		log.Fatalf("查询学生记录失败: %v", err)
	}
	defer rows.Close()

	fmt.Println("ID\tStudentID\tUserID\tName")
	fmt.Println("---------------------------------------------------")
	hasRecords := false
	for rows.Next() {
		hasRecords = true
		var id int
		var studentId string
		var userId int
		var name string
		if err := rows.Scan(&id, &studentId, &userId, &name); err != nil {
			log.Fatalf("扫描结果失败: %v", err)
		}
		fmt.Printf("%d\t%s\t\t%d\t%s\n", id, studentId, userId, name)
	}

	if !hasRecords {
		fmt.Println("没有找到学生记录")
	}

	fmt.Println("\n验证完成！")
}