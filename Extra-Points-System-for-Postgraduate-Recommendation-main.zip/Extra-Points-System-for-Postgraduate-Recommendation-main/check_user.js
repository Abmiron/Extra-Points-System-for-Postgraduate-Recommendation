// 检查localStorage中是否存在指定用户
console.log('正在检查用户是否存在...');

try {
  // 从localStorage获取用户数据
  const usersStr = localStorage.getItem('users');
  
  if (!usersStr) {
    console.log('localStorage中没有用户数据');
    return;
  }
  
  const users = JSON.parse(usersStr);
  console.log('所有用户名:', Object.keys(users));
  
  // 检查是否存在学号为123456的用户
  const targetUsername = '123456';
  const targetUser = users[targetUsername];
  
  if (targetUser) {
    console.log('找到用户！');
    console.log('用户详情:', targetUser);
    console.log(`学生名: ${targetUser.name || targetUser.studentName}`);
    console.log(`学号: ${targetUser.username || targetUser.studentId}`);
    console.log(`角色: ${targetUser.role}`);
    console.log(`状态: ${targetUser.status || 'active'}`);
  } else {
    console.log('未找到学号为123456的用户');
    
    // 尝试遍历查找学生名为hhh的用户
    console.log('\n尝试查找学生名为hhh的用户...');
    let found = false;
    
    for (const username in users) {
      const user = users[username];
      if (user.name === 'hhh' || user.studentName === 'hhh') {
        console.log('找到学生名为hhh的用户！');
        console.log('用户名/学号:', username);
        console.log('用户详情:', user);
        found = true;
        break;
      }
    }
    
    if (!found) {
      console.log('未找到学生名为hhh的用户');
    }
  }
} catch (error) {
  console.error('检查用户时发生错误:', error);
}