// 修改版用户检查脚本
console.log('正在检查用户数据...');

// 模拟localStorage的文件路径
const fs = require('fs');
const path = require('path');

// 检查项目中可能存在的用户数据文件
const checkUserData = () => {
  console.log('\n1. 检查项目目录...');
  
  // 检查test-vue-app目录
  const testVueAppDir = path.join(__dirname, 'test-vue-app');
  if (fs.existsSync(testVueAppDir)) {
    console.log('找到test-vue-app目录');
    
    // 检查是否有localStorage相关的数据文件
    const checkForLocalStorageFiles = () => {
      console.log('\n2. 检查localStorage相关文件...');
      // 在实际浏览器中，localStorage数据存储在浏览器的配置文件中
      // 这里我们尝试查找项目中可能存在的用户数据文件
      
      // 检查是否有localStorage模拟文件
      const possibleStorageFiles = [
        path.join(testVueAppDir, 'localStorage.json'),
        path.join(testVueAppDir, 'src', 'data', 'users.json'),
        path.join(testVueAppDir, 'src', 'assets', 'data', 'users.json')
      ];
      
      let foundFile = false;
      for (const file of possibleStorageFiles) {
        if (fs.existsSync(file)) {
          console.log(`找到用户数据文件: ${file}`);
          try {
            const data = fs.readFileSync(file, 'utf8');
            const users = JSON.parse(data);
            console.log('用户数据:', JSON.stringify(users, null, 2));
          } catch (error) {
            console.error(`读取文件失败: ${error.message}`);
          }
          foundFile = true;
        }
      }
      
      if (!foundFile) {
        console.log('未找到明显的用户数据文件');
      }
    };
    
    checkForLocalStorageFiles();
  } else {
    console.log('未找到test-vue-app目录');
  }
  
  // 分析UserManagement.vue组件中的默认用户数据
  console.log('\n3. 分析UserManagement.vue中的默认用户数据...');
  const userManagementFile = path.join(testVueAppDir, 'src', 'components', 'admin', 'UserManagement.vue');
  if (fs.existsSync(userManagementFile)) {
    const content = fs.readFileSync(userManagementFile, 'utf8');
    
    // 查找默认用户数据相关的代码
    const defaultUsersMatch = content.match(/users.value\s*=\s*\[([\s\S]*?)\]/);
    if (defaultUsersMatch && defaultUsersMatch[1]) {
      console.log('找到默认用户数据定义');
      console.log('默认用户:', defaultUsersMatch[1]);
    } else {
      console.log('在UserManagement.vue中未找到明确的默认用户数据');
    }
  } else {
    console.log('未找到UserManagement.vue文件');
  }
  
  console.log('\n4. 检查后端数据库连接...');
  console.log('注意: 由于psql命令不可用，无法直接查询PostgreSQL数据库');
  console.log('数据库配置信息:');
  console.log('- 数据库类型: PostgreSQL');
  console.log('- 主机: localhost');
  console.log('- 端口: 5432');
  console.log('- 用户名: postgres');
  console.log('- 数据库名: hd_golang');
  console.log('\n建议使用PostgreSQL客户端工具(如pgAdmin)连接数据库并执行以下查询:');
  console.log('SELECT u.id, u.username, u.role, u.status, u.created_at, u.last_login_at,');
  console.log('       COALESCE(s.student_id, \'\') as student_id,');
  console.log('       COALESCE(s.name, \'\') as student_name,');
  console.log('       COALESCE(s.department, \'\') as department,');
  console.log('       COALESCE(s.major, \'\') as major');
  console.log('FROM users u');
  console.log('LEFT JOIN students s ON u.id = s.user_id');
  console.log('ORDER BY u.created_at DESC;');
};

checkUserData();
console.log('\n检查完成！');
